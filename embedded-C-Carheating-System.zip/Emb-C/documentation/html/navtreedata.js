/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "CarHeatingSystem", "index.html", [
    [ "carHeatingsystem by Karthika @subpage main.c", "index.html", null ],
    [ "Emb-C", "md_C__Users_Hp_OneDrive_Desktop_test_Emb_C_README.html", [
      [ "Car Heater Monitoring Embedded System", "md_C__Users_Hp_OneDrive_Desktop_test_Emb_C_README.html#autotoc_md1", [
        [ "In Action", "md_C__Users_Hp_OneDrive_Desktop_test_Emb_C_README.html#autotoc_md2", [
          [ "LED Actuator that indicates the status of the heater and presence of the driver", "md_C__Users_Hp_OneDrive_Desktop_test_Emb_C_README.html#autotoc_md3", null ],
          [ "CIRCUIT DIAGRAM", "md_C__Users_Hp_OneDrive_Desktop_test_Emb_C_README.html#autotoc_md4", null ],
          [ "LED does not glow when both heater and seater is off", "md_C__Users_Hp_OneDrive_Desktop_test_Emb_C_README.html#autotoc_md5", null ],
          [ "LED glows when both heater and seater is on", "md_C__Users_Hp_OneDrive_Desktop_test_Emb_C_README.html#autotoc_md6", null ],
          [ "Either the heater is not ON or the Seater is not present", "md_C__Users_Hp_OneDrive_Desktop_test_Emb_C_README.html#autotoc_md7", null ],
          [ "Driver is sitting Heater is Off", "md_C__Users_Hp_OneDrive_Desktop_test_Emb_C_README.html#autotoc_md8", null ]
        ] ],
        [ "The range of temperatures that can be set in heater when passenger is in car", "md_C__Users_Hp_OneDrive_Desktop_test_Emb_C_README.html#autotoc_md9", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Functions", "globals_func.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"adc_8h.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';