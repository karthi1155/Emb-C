var adc_8h =
[
    [ "initADC", "adc_8h.html#ab3166bd1ba3160d3bac85daddb12f947", null ],
    [ "readADC", "adc_8h.html#aa2ddbf4d47d7baabcb6296818b19988e", null ]
];