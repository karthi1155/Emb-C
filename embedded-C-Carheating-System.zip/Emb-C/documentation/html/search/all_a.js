var searchData=
[
  ['temp_5fsensor_5fip_16',['TEMP_SENSOR_IP',['../project__config_8h.html#aa3e52cde3f39c25056cad005c4040fb6',1,'project_config.h']]]
];
