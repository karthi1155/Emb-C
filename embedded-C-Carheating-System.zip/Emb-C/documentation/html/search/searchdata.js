var indexSectionsWithContent =
{
  0: "aceghilprst",
  1: "alp",
  2: "cgir",
  3: "hst",
  4: "ce"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "defines",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Macros",
  4: "Pages"
};

