#include<stdio.h>
int main()
{
    printf("Welcome to Module 2-Embedded C");
}